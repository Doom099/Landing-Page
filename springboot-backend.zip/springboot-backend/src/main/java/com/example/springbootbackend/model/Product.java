package com.example.springbootbackend.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "products")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column( name="id" ,length=3)
    private Integer id;
    @Column( name="product_name" ,length=50)
    private String product_name;
    @Column( name="product_price" ,length=50)
    private double product_price;

    @Lob
    @Column( name="product_pic", columnDefinition = "BLOB")
    private byte[] product_pic;
}
