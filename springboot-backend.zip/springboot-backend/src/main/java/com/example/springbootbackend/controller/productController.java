package com.example.springbootbackend.controller;

import com.example.springbootbackend.exception.ResourceNotFoundException;
import com.example.springbootbackend.model.Product;
import com.example.springbootbackend.repository.productRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;


import java.util.Base64;
import java.util.List;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/rest/api/product")
public class productController {
    @Autowired
    private productRepository ProductRepository;

    //getall
    @GetMapping
    public List<Product> getAllProduct()
    {
        return ProductRepository.findAll();
    }
    // Create
    @PostMapping
    public Product createProduct(
            @RequestParam("product_name") String product_name,
            @RequestParam("product_price") double product_price,
            @RequestPart("product_pic") MultipartFile productPic) {


        try {
            Product product = new Product();
            product.setProduct_name(product_name);
            product.setProduct_price(product_price);
            product.setProduct_pic(productPic.getBytes());
            return ProductRepository.save(product);
        } catch (IOException e) {
            // Handle exception
            throw new RuntimeException("Failed to process image", e);
        }

    }

    //gtbyid
    @GetMapping("{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Integer id){
        Product product = ProductRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));

        return ResponseEntity.ok(product);
    }

    //update
    @PutMapping("{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Integer id,@RequestBody Product productNew){
        Product updateProduct = ProductRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not existe with id : " + id));

        updateProduct.setProduct_name(productNew.getProduct_name());
        updateProduct.setProduct_price(productNew.getProduct_price());
        updateProduct.setProduct_pic(productNew.getProduct_pic());

        ProductRepository.save(updateProduct);

        return ResponseEntity.ok(updateProduct);
    }

    //delete
    @DeleteMapping("{id}")
    public ResponseEntity<HttpStatus> deleteProduct(@PathVariable Integer id){
        Product product = ProductRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not existe with id : " + id));

        ProductRepository.delete(product);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
