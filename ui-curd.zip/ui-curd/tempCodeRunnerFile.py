from flask import Flask, render_template, request, redirect, url_for
import cx_Oracle
import base64

app = Flask(__name__)

DB_USER = 'osama_db'
DB_PASSWORD = '0000'
DB_DSN = 'localhost:1521/XE'  


def connect_to_db():
    connection = cx_Oracle.connect(DB_USER, DB_PASSWORD, DB_DSN)
    return connection


@app.route('/')
def index():
    connection = connect_to_db()
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM products')
    products = cursor.fetchall()
    connection.close()
    return render_template('index.html', products=products)

@app.route('/add', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        product_name = request.form['product_name']
        product_price = request.form['product_price']
        product_pic = request.files['product_pic'].read()

        connection = connect_to_db()
        cursor = connection.cursor()
        cursor.execute('INSERT INTO products (product_name, product_price, product_pic) VALUES (:name, :price, :pic)',
                       {'name': product_name, 'price': product_price, 'pic': product_pic})
        connection.commit()
        connection.close()

        return redirect(url_for('index'))

    return render_template('add.html')

@app.route('/edit/<int:product_id>', methods=['GET', 'POST'])
def edit_product(product_id):
    connection = connect_to_db()
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM products WHERE id = :id', {'id': product_id})
    product = cursor.fetchone()
    connection.close()

    if request.method == 'POST':
        product_name = request.form['product_name']
        product_price = request.form['product_price']
        product_pic = request.files['product_pic'].read()

        connection = connect_to_db()
        cursor = connection.cursor()
        cursor.execute('UPDATE products SET product_name=:name, product_price=:price, product_pic=:pic WHERE id=:id',
                       {'name': product_name, 'price': product_price, 'pic': product_pic, 'id': product_id})
        connection.commit()
        connection.close()

        return redirect(url_for('index'))

    return render_template('edit.html', product=product)

@app.route('/delete/<int:product_id>')
def delete_product(product_id):
    connection = connect_to_db()
    cursor = connection.cursor()
    cursor.execute('DELETE FROM products WHERE id = :id', {'id': product_id})
    connection.commit()
    connection.close()

    return redirect(url_for('index'))



if __name__ == '__main__':
    app.run(debug=True)
